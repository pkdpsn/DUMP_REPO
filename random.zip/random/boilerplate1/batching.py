import asyncio
from typing import Any, List
from model import model

class BatchItem:
    def __init__(self, data: Any, future: asyncio.Future):
        self.data = data
        self.future = future

class BatchProcessor:
    def __init__(
        self,
        max_batch_size: int = 8,
        max_wait_ms: int = 20,
    ):
        self.queue: asyncio.Queue[BatchItem] = asyncio.Queue()
        self.max_batch_size = max_batch_size
        self.max_wait_ms = max_wait_ms

    async def start(self):
        asyncio.create_task(self._batch_worker())

    async def submit(self, data: Any):
        future = asyncio.get_event_loop().create_future()
        await self.queue.put(BatchItem(data, future))
        return await future

    async def _batch_worker(self):
        while True:
            batch: List[BatchItem] = []

            # always wait for at least 1 item
            item = await self.queue.get()
            batch.append(item)

            start_time = asyncio.get_event_loop().time()

            # collect more items
            while len(batch) < self.max_batch_size:
                timeout = self.max_wait_ms / 1000 - (
                    asyncio.get_event_loop().time() - start_time
                )
                if timeout <= 0:
                    break
                try:
                    item = await asyncio.wait_for(self.queue.get(), timeout)
                    batch.append(item)
                except asyncio.TimeoutError:
                    break

            # run model once on batch
            inputs = [item.data for item in batch]
            outputs = model.predict(inputs)
            print(f"Running batch of size {len(inputs)}")

            # resolve futures
            for item, output in zip(batch, outputs):
                item.future.set_result(output)
