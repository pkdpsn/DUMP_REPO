# app/main.py
from fastapi import FastAPI
from pydantic import BaseModel
from batching import BatchProcessor

app = FastAPI()

batcher = BatchProcessor(
    max_batch_size=16,
    max_wait_ms=25,
)

class InferenceRequest(BaseModel):
    text: str

class InferenceResponse(BaseModel):
    output: str

@app.on_event("startup")
async def startup():
    await batcher.start()

@app.post("/infer", response_model=InferenceResponse)
async def infer(req: InferenceRequest):
    result = await batcher.submit(req.text)
    return {"output": result}

@app.get("/health")
def health():
    return {"status": "ok"}
