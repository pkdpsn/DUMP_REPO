# app/model.py
import time

class DummyModel:
    def predict(self, texts: list[str]) -> list[str]:
        time.sleep(0.1)  # simulate GPU/CPU work
        print(f"Running batch of size {len(texts)} {texts}")
        return [text.upper() for text in texts]

model = DummyModel()
