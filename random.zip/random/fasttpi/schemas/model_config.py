from typing import List, Optional, Literal, Dict , Tuple
from pydantic import BaseModel, Field , model_validator

class BatchingConfig(BaseModel):
    enabled: bool = True
    max_batch_size: int = Field(gt=0, le=1024)
    max_wait_ms: int = Field(gt=0, le=5000)

    @model_validator(mode="after")
    def validate_batching(self):
        if self.enabled and self.max_batch_size <= 0:
            raise ValueError("max_batch_size must be > 0 when batching is enabled")
        return self

class EvictionConfig(BaseModel):
    enabled: bool = False
    idle_timeout_sec: int = Field(ge=0)
    offload_to: Optional[Literal["cpu", "disk"]] = None

    @model_validator(mode="after")
    def validate_eviction(self):
        if self.enabled:
            if self.idle_timeout_sec <= 0:
                raise ValueError("idle_timeout_sec must be > 0 when eviction enabled")
            if self.offload_to is None:
                raise ValueError("offload_to must be set when eviction enabled")
        return self


class ModelConfig(BaseModel):
    name: str
    type: Literal["reranker", "embedding"]
    version: str

    model_path: str
    device: str = "cpu"
    priority: Literal["high", "low"] = "low"

    max_length: Optional[int] = None
    normalize: Optional[bool] = None

    batching: BatchingConfig
    eviction: EvictionConfig

    @model_validator(mode="after")
    def validate_type_specific(self):
        if self.type == "reranker" and self.max_length is None:
            raise ValueError("reranker models must define max_length")
        if self.type == "embedding" and self.normalize is None:
            raise ValueError("embedding models must define normalize")
        return self

class ModelRegistryConfig(BaseModel):
    models: List[ModelConfig]

    @model_validator(mode="after")
    def validate_unique_versions(self):
        seen: Dict[Tuple[str, str], str] = {}

        for m in self.models:
            key = (m.type, m.version)
            if key in seen:
                raise ValueError(
                    f"Duplicate model detected: type={m.type}, version={m.version}"
                )
            seen[key] = m.name

        return self

    def get_model(self, *, type: str, version: str) -> ModelConfig:
        for m in self.models:
            if m.type == type and m.version == version:
                return m
        raise KeyError(f"Model not found: type={type}, version={version}")

    def list_versions(self, type: str) -> List[str]:
        return [m.version for m in self.models if m.type == type]


