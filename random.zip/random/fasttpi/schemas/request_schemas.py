from pydantic import BaseModel
from typing import List, Optional, Union

class RerankRequest(BaseModel):
    query: str
    chunks: List[str]
    
class RerankResponse(BaseModel):
    query: str
    ranked_chunks: List[dict]
    # reults: List
    #....
    
class NerRequest(BaseModel):
    text: str
    
class NerResponse(BaseModel):
    text: str
    organizations: List
    persons: List
    tickers: List
    results: List
    
    