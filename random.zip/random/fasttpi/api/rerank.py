from fastapi import APIRouter, HTTPException
from core.model_manager import ModelManager
from schemas.request_schemas import RerankRequest , RerankResponse

router = APIRouter()

@router.post("/{version}")
async def rerank(version: str, request: RerankRequest) -> RerankResponse:
    model_name = f"reranker_{version}"  # e.g., "reranker_v1"

    try:
        model = await ModelManager().get_model(model_name)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Reranker version '{version}' not configured")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load model: {str(e)}")
    
    result = await model.submit_request(request.model_dump())
    print(f"{type(result)} {result} ")
    return RerankResponse(query=request.query, ranked_chunks=result)