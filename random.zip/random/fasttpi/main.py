import os
import asyncio
import logging
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List

from fastapi import FastAPI, Request, status
# from fastapi.middleware.cors import CORSMiddleware ############ check 
from fastapi.responses import JSONResponse

from core.load_config import load_model_registry 
from core.model_manager import ModelManager

# from api.health import router as health_router
from api.rerank import router as rerank_router

# Setup logger early (before lifespan)
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
)

# Config path – later replace with env var if needed
CONFIG_PATH = os.getenv("MODEL_CONFIG_PATH", "configs/dev.yaml")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting up SLM Inference Service")

    # Load full config/registry
    settings = load_model_registry(CONFIG_PATH)

    # Initialize ModelManager with all configured models
    await ModelManager().initialize(settings.models)

    # Preload hot models (high priority or non-evictable)
    hot_models: List[str] = [
        cfg.name
        for cfg in settings.models
        if getattr(cfg, "priority", None) == "high" 
        or not getattr(cfg.eviction, "get", lambda *_: False)("enabled", False)
    ]

    if hot_models:
        logger.info(f"Preloading hot models: {hot_models}")
        await ModelManager().preload_hot_models(hot_models)

    logger.info("Startup complete service ready")
    yield

    logger.info("Shutting down SLM Inference Service")
    await ModelManager().shutdown()
    logger.info("Shutdown complete")

app = FastAPI(
    title="SLM Inference Service",
    description="API for SLM model inference tasks",
    version="1.0.0",
    lifespan=lifespan,
)


# Include routers
# app.include_router(health_router, tags=["health"])
app.include_router(rerank_router, prefix="/rerank", tags=["rerank"])
# app.include_router(embedding_router, prefix="/embed", tags=["embedding"])

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(
        f"Unhandled exception for request {request.method} {request.url}: {exc}",
        exc_info=True,
        extra={
            "path": request.url.path,
            "method": request.method,
            "client": request.client.host if request.client else None,
        }
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal Server Error"},
    )