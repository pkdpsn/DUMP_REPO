import asyncio
import pytest

from core.batcher import Batcher


# ---------------------------------------------------------------------
# 1. Basic batching works
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_basic_batching():
    async def process_fn(requests):
        await asyncio.sleep(0.01)
        return [r["x"] * 2 for r in requests]

    batcher = Batcher(
        max_batch_size=8,
        max_wait_ms=50,
        process_fn=process_fn,
        name="basic-test",
    )
    batcher.start()

    results = await asyncio.gather(
        *[batcher.submit({"x": i}) for i in range(5)]
    )

    assert results == [0, 2, 4, 6, 8]

    await batcher.stop()


# ---------------------------------------------------------------------
# 2. max_batch_size is enforced
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_max_batch_size_enforced():
    batch_sizes = []

    async def process_fn(requests):
        batch_sizes.append(len(requests))
        await asyncio.sleep(0.01)
        return [r["x"] for r in requests]

    batcher = Batcher(
        max_batch_size=4,
        max_wait_ms=100,
        process_fn=process_fn,
        name="batch-size-test",
    )
    batcher.start()

    await asyncio.gather(
        *[batcher.submit({"x": i}) for i in range(10)]
    )

    await batcher.stop()

    assert batch_sizes == [4, 4, 2]


# ---------------------------------------------------------------------
# 3. Timeout-based batching
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_timeout_batching():
    batch_sizes = []

    async def process_fn(requests):
        batch_sizes.append(len(requests))
        return [r["x"] for r in requests]

    batcher = Batcher(
        max_batch_size=10,
        max_wait_ms=20,  # short timeout
        process_fn=process_fn,
        name="timeout-test",
    )
    batcher.start()

    await batcher.submit({"x": 1})
    await asyncio.sleep(0.05)  # exceed max_wait
    await batcher.submit({"x": 2})

    await batcher.stop()

    assert batch_sizes == [1, 1]


# ---------------------------------------------------------------------
# 4. Order preservation (CRITICAL)
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_order_preserved():
    async def process_fn(requests):
        await asyncio.sleep(0.01)
        return [r["id"] for r in requests]

    batcher = Batcher(
        max_batch_size=5,
        max_wait_ms=50,
        process_fn=process_fn,
        name="order-test",
    )
    batcher.start()

    tasks = [
        batcher.submit({"id": i})
        for i in range(7)
    ]

    results = await asyncio.gather(*tasks)

    assert results == list(range(7))

    await batcher.stop()


# ---------------------------------------------------------------------
# 5. Error propagation (batch failure)
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_error_propagation():
    async def process_fn(requests):
        raise RuntimeError("model failure")

    batcher = Batcher(
        max_batch_size=4,
        max_wait_ms=50,
        process_fn=process_fn,
        name="error-test",
    )
    batcher.start()

    tasks = [
        asyncio.create_task(batcher.submit({"x": i}))
        for i in range(3)
    ]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    assert all(isinstance(r, RuntimeError) for r in results)

    await batcher.stop()


# ---------------------------------------------------------------------
# 6. Shutdown fails pending requests cleanly
# ---------------------------------------------------------------------

# @pytest.mark.asyncio
# async def test_shutdown_fails_pending_requests():
#     async def process_fn(requests):
#         await asyncio.sleep(0.2)
#         return [r["x"] for r in requests]

#     batcher = Batcher(
#         max_batch_size=4,
#         max_wait_ms=100,
#         process_fn=process_fn,
#         name="shutdown-test",
#     )
#     batcher.start()

#     task = asyncio.create_task(batcher.submit({"x": 1}))

#     await asyncio.sleep(0.01)
#     await batcher.stop()

#     with pytest.raises(RuntimeError):
#         await task


# ---------------------------------------------------------------------
# 7. Batcher not started → submit fails
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_submit_without_start_fails():
    async def process_fn(requests):
        return requests

    batcher = Batcher(
        max_batch_size=4,
        max_wait_ms=50,
        process_fn=process_fn,
        name="not-started-test",
    )

    with pytest.raises(RuntimeError):
        await batcher.submit({"x": 1})
