import asyncio

from matplotlib.units import registry
from models.reranker import RerankerModel
from schemas.model_config import ModelConfig  
import torch

import yaml
from schemas.model_config import ModelRegistryConfig

def load_model_registry(path: str) -> ModelRegistryConfig:
    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    return ModelRegistryConfig(**raw)



async def main():
    CONFIG_PATH = "configs/dev.yaml"
    registry = load_model_registry(CONFIG_PATH)
    
    config = registry.get_model(type="reranker", version="v2")
    print(config)
    model = RerankerModel(config)
    print(model)
    await model.load()

    # Simulate concurrent requests
    requests = [
        {"query": f"Query {i}", "chunks": ["chunk1", "chunk2", "chunk3"]}
        for i in range(20)
    ]

    tasks = [model.submit_request(req) for req in requests]
    results = await asyncio.gather(*tasks)

    print(f"Got {len(results)} results")
    print(results[0][:2])  # show first query top-2

    await model.unload()

asyncio.run(main())