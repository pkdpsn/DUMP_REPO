import asyncio
import logging
from typing import Dict, Optional, List

from models.base import BaseModel
from schemas.model_config import ModelConfig
from models.reranker import RerankerModel  # your concrete subclass

logger = logging.getLogger(__name__)

class ModelManager:
    """
    Singleton ModelManager:
    - Holds all configured models (lazy instantiation)
    - Thread-safe lazy loading on first request
    - Central place for preload, eviction checker, shutdown
    """
    _instance: Optional["ModelManager"] = None

    def __new__(cls) -> "ModelManager":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
            cls._instance.models: Dict[str, BaseModel] = {}
            cls._instance.configs: Dict[str, ModelConfig] = {}
            cls._instance._lock = asyncio.Lock()
        return cls._instance

    async def initialize(self, models_config: List[ModelConfig]) -> None:
        """
        Call once on app startup with full list of possible models.
        Now async to allow use of asyncio.Lock.
        """
        if self._initialized:
            return

        async with self._lock:
            if self._initialized:
                return

            for cfg in models_config:
                if cfg.name in self.configs:
                    raise ValueError(f"Duplicate model name: {cfg.name}")
                self.configs[cfg.name] = cfg
                # Lazy – do NOT instantiate yet

            self._initialized = True
            logger.info(
                f"ModelManager initialized with {len(self.configs)} configured models: "
                f"{list(self.configs.keys())}"
            )

    async def get_model(self, model_name: str) -> BaseModel:
        """Public method: returns loaded model instance (lazy loads if needed)"""
        if not self._initialized:
            raise RuntimeError("ModelManager not initialized – call initialize() first")

        # Fast path: already instantiated
        if model_name in self.models:
            model = self.models[model_name]
            await model.ensure_loaded()  # safe noop if already loaded
            return model

        async with self._lock:
            # Double-check after lock
            if model_name in self.models:
                model = self.models[model_name]
                await model.ensure_loaded()
                return model

            if model_name not in self.configs:
                raise KeyError(f"Model '{model_name}' not found in config")

            cfg = self.configs[model_name]
            logger.info(f"Lazy instantiating and loading model '{model_name}' (version={cfg.version})")

            # Factory pattern
            if cfg.type == "reranker":
                model_instance: BaseModel = RerankerModel(cfg)
            else:
                raise ValueError(f"Unsupported model type: {cfg.type}")

            await model_instance.load()  # loads model + starts batcher

            self.models[model_name] = model_instance
            return model_instance

    async def preload_hot_models(self, hot_names: List[str]) -> None:
        """Preload specified models on startup"""
        tasks = []
        for name in hot_names:
            if name in self.configs:
                tasks.append(self.get_model(name))
            else:
                logger.warning(f"Hot model '{name}' not in config – skipping preload")

        if tasks:
            await asyncio.gather(*tasks)
            logger.info(f"Preloaded {len(tasks)} hot models")

    async def shutdown(self) -> None:
        """Unload all models gracefully"""
        tasks = []
        for model in self.models.values():
            tasks.append(model.unload())

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
            logger.info(f"Unloaded {len(tasks)} models during shutdown")