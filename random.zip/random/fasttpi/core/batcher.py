import asyncio
from datetime import datetime
from typing import List, Dict, Any, Callable, Awaitable, Optional
import logging

logger = logging.getLogger(__name__)

# process_fn must:
#   - accept a list of requests
#   - return a list of results in the same order
ProcessFn = Callable[[List[Dict[str, Any]]], Awaitable[List[Any]]]


class BatchItem:
    """Internal item stored in the queue"""
    __slots__ = ("request", "future")

    def __init__(self, request: Dict[str, Any], future: asyncio.Future):
        self.request = request
        self.future = future


class Batcher:
    """
    Async batcher with dynamic batching (max_batch_size + max_wait_ms)

    Designed to be owned by exactly ONE model instance
    (e.g. reranker:v1, ner:v2, embeddings:v1)
    """

    def __init__(
        self,
        max_batch_size: int,
        max_wait_ms: float,
        process_fn: ProcessFn,
        name: str = "batcher",
    ):
        self.max_batch_size = max_batch_size
        self.max_wait_s = max_wait_ms / 1000.0
        self.process_fn = process_fn
        self.name = name

        self.queue: asyncio.Queue[BatchItem] = asyncio.Queue()
        self._worker_task: Optional[asyncio.Task] = None
        self._shutdown_event = asyncio.Event()

        logger.info(
            f"Created Batcher '{self.name}' "
            f"(max_batch={self.max_batch_size}, max_wait={max_wait_ms}ms)"
        )

    def start(self) -> None:
        """Start the background worker loop"""
        if self._worker_task is None or self._worker_task.done():
            self._shutdown_event.clear()
            self._worker_task = asyncio.create_task(self._worker_loop())
            logger.debug(f"Batcher '{self.name}' started")

    async def stop(self) -> None:
        """Stop the worker and fail all pending requests"""
        if self._worker_task is None:
            return

        self._shutdown_event.set()
        self._worker_task.cancel()

        try:
            await self._worker_task
        except asyncio.CancelledError:
            pass

        # Fail all remaining queued requests
        while not self.queue.empty():
            item = self.queue.get_nowait()
            if not item.future.done():
                item.future.set_exception(
                    RuntimeError(f"Batcher '{self.name}' shut down during request")
                )

        self._worker_task = None
        logger.debug(f"Batcher '{self.name}' stopped")

    async def _worker_loop(self) -> None:
        """Main loop: gather → batch → process → resolve futures"""
        while not self._shutdown_event.is_set():
            try:
                # Wait for at least one request
                first_item = await self.queue.get()
                batch: List[BatchItem] = [first_item]
                batch_requests: List[Dict[str, Any]] = [first_item.request]

                # Dynamic batching window
                deadline = asyncio.get_running_loop().time() + self.max_wait_s

                while len(batch) < self.max_batch_size:
                    remaining = deadline - asyncio.get_running_loop().time()
                    if remaining <= 0:
                        break

                    try:
                        item = await asyncio.wait_for(self.queue.get(), timeout=remaining)
                        batch.append(item)
                        batch_requests.append(item.request)
                    except asyncio.TimeoutError:
                        break

                batch_size = len(batch)
                start_time = datetime.utcnow()

                try:
                    # IMPORTANT:
                    # process_fn MUST be async-safe
                    results = await self.process_fn(batch_requests)

                    if len(results) != batch_size:
                        raise RuntimeError(
                            f"process_fn returned {len(results)} results "
                            f"for batch of size {batch_size}"
                        )

                    for item, result in zip(batch, results):
                        if not item.future.done():
                            item.future.set_result(result)

                except Exception as e:
                    logger.error(
                        f"Error processing batch in '{self.name}': {e}",
                        exc_info=True,
                    )
                    for item in batch:
                        if not item.future.done():
                            item.future.set_exception(e)

                latency = (datetime.utcnow() - start_time).total_seconds()
                logger.debug(
                    f"Batcher '{self.name}' processed batch of {batch_size} "
                    f"in {latency:.3f}s "
                    f"(avg {latency / batch_size:.3f}s / request)"
                )

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(
                    f"Unexpected error in batcher '{self.name}' worker: {e}",
                    exc_info=True,
                )

    async def submit(self, request: Dict[str, Any]) -> Any:
        """
        Submit a single request and await its result
        (called from FastAPI endpoints)
        """
        if self._worker_task is None or self._worker_task.done():
            raise RuntimeError(f"Batcher '{self.name}' is not running")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        await self.queue.put(BatchItem(request=request, future=future))
        return await future
