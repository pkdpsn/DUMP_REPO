import yaml
from schemas.model_config import ModelRegistryConfig

def load_model_registry(path: str) -> ModelRegistryConfig:
    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    return ModelRegistryConfig(**raw)