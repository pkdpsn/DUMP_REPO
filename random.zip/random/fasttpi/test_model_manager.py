import asyncio
import pytest
import pytest_asyncio

from core.model_manager import ModelManager
from schemas.model_config import ModelConfig, BatchingConfig, EvictionConfig
from models.base import BaseModel


# ---------------------------------------------------------------------
# Fake model for testing (NO torch / HF)
# ---------------------------------------------------------------------

class FakeModel(BaseModel):
    def __init__(self, config):
        super().__init__(config)
        self.load_calls = 0
        self.unload_calls = 0
        self.loaded = False

    async def load(self) -> None:
        self.load_calls += 1
        self.loaded = True

    async def unload(self) -> None:
        self.unload_calls += 1
        self.loaded = False

    async def ensure_loaded(self) -> None:
        # Mimic real behavior: load only once
        if not self.loaded:
            await self.load()

    async def predict_batch(self, batch_inputs):
        return batch_inputs


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------

@pytest_asyncio.fixture
async def manager(monkeypatch):
    """
    Fresh ModelManager singleton per test
    """
    mgr = ModelManager()

    # Reset singleton state manually (important)
    mgr._initialized = False
    mgr.models.clear()
    mgr.configs.clear()

    # Monkeypatch RerankerModel to FakeModel
    monkeypatch.setattr(
        "core.model_manager.RerankerModel",
        FakeModel,
    )

    yield mgr

    await mgr.shutdown()


@pytest.fixture
def model_configs():
    return [
        ModelConfig(
            name="reranker_v1",
            type="reranker",
            version="v1",
            model_path="dummy",
            device="cpu",
            max_length=128,  # required for reranker
            batching=BatchingConfig(enabled=False, max_batch_size=1, max_wait_ms=1),
            eviction=EvictionConfig(enabled=False, idle_timeout_sec=0),
        ),
        ModelConfig(
            name="reranker_v2",
            type="reranker",
            version="v2",
            model_path="dummy",
            device="cpu",
            max_length=128,  # required for reranker
            batching=BatchingConfig(enabled=False, max_batch_size=1, max_wait_ms=1),
            eviction=EvictionConfig(enabled=False, idle_timeout_sec=0),
        ),
    ]

# ---------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_initialize_idempotent(manager, model_configs):
    await manager.initialize(model_configs)
    await manager.initialize(model_configs)  # second call should be no-op

    assert len(manager.configs) == 2
    assert manager._initialized is True


@pytest.mark.asyncio
async def test_get_model_lazy_load(manager, model_configs):
    await manager.initialize(model_configs)

    model = await manager.get_model("reranker_v1")

    assert isinstance(model, FakeModel)
    assert model.loaded is True
    assert model.load_calls == 1

    # Second get should NOT reload
    model2 = await manager.get_model("reranker_v1")
    assert model is model2
    assert model.load_calls == 1


@pytest.mark.asyncio
async def test_concurrent_get_model_single_load(manager, model_configs):
    await manager.initialize(model_configs)

    results = await asyncio.gather(
        manager.get_model("reranker_v1"),
        manager.get_model("reranker_v1"),
        manager.get_model("reranker_v1"),
    )

    model = results[0]
    assert all(m is model for m in results)
    assert model.load_calls == 1


@pytest.mark.asyncio
async def test_get_model_unknown_name(manager, model_configs):
    await manager.initialize(model_configs)

    with pytest.raises(KeyError):
        await manager.get_model("unknown_model")


@pytest.mark.asyncio
async def test_preload_hot_models(manager, model_configs):
    await manager.initialize(model_configs)

    await manager.preload_hot_models(["reranker_v1"])

    assert "reranker_v1" in manager.models
    assert manager.models["reranker_v1"].loaded is True

    # Non-hot model should not be loaded
    assert "reranker_v2" not in manager.models


@pytest.mark.asyncio
async def test_shutdown_unloads_all(manager, model_configs):
    await manager.initialize(model_configs)

    m1 = await manager.get_model("reranker_v1")
    m2 = await manager.get_model("reranker_v2")

    assert m1.loaded and m2.loaded

    await manager.shutdown()

    assert m1.loaded is False
    assert m2.loaded is False
    assert m1.unload_calls == 1
    assert m2.unload_calls == 1
