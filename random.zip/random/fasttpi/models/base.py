from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, List, Optional
import torch
from datetime import datetime
import asyncio
from schemas.model_config import ModelConfig ##### check impotr path


## maybe not used now in V1
class ModelState(Enum):
    """Model lifecycle states"""
    UNLOADED = "unloaded"
    LOADING = "loading"
    ACTIVE = "active"
    IDLE = "idle"
    EVICTED = "evicted"
    ERROR = "error"


class BaseModel(ABC):
    """Abstract base class for all models"""
    
    def __init__(self, config: ModelConfig):
        """Initialize from validated config"""
        self.config = config
        self.name = config.name
        self.model_type = config.type
        self.version = config.version
        self.model_path = config.model_path
        self.target_device = config.device
        self.priority = config.priority
        
        # Eviction settings ---- no evict in v1 not tested 
        self.eviction_enabled = config.eviction.enabled
        self.idle_timeout_sec = config.eviction.idle_timeout_sec
        self.offload_to = config.eviction.offload_to
        
        # Batching settings
        self.batching_enabled = config.batching.enabled
        self.max_batch_size = config.batching.max_batch_size
        self.max_wait_ms = config.batching.max_wait_ms
        
        # State tracking
        self._state = ModelState.UNLOADED
        self._current_device = None
        self._last_used = None
        self._load_lock = asyncio.Lock()
        self._error_message = None
        
        # Model instance (set by subclasses)
        self.model = None
        
    @property
    def state(self) -> ModelState:
        return self._state
    
    @property
    def current_device(self) -> Optional[str]:
        return self._current_device
    
    @property
    def last_used(self) -> Optional[datetime]:
        return self._last_used
    
    @property
    def error_message(self) -> Optional[str]:
        return self._error_message
    
    @property
    def idle_time_sec(self) -> float:
        """Calculate seconds since last use"""
        if self._last_used is None:
            return 0
        return (datetime.utcnow() - self._last_used).total_seconds()
    
    @property
    def is_loaded(self) -> bool:
        """Check if model is loaded and ready"""
        return self._state in [ModelState.ACTIVE, ModelState.IDLE]
    
    @property
    def should_evict(self) -> bool:
        """Check if model should be evicted based on idle time"""
        if not self.eviction_enabled:
            return False
        if not self.is_loaded:
            return False
        return self.idle_time_sec > self.idle_timeout_sec
    
    async def ensure_loaded(self) -> None:
        """Ensure model is loaded and ready (thread-safe)"""
        if self.is_loaded:
            self.mark_active()
            return
        
        async with self._load_lock:
            # Double-check after acquiring lock
            if self.is_loaded:
                self.mark_active()
                return
            
            await self._load()
    
    async def _load(self) -> None:
        """Internal load method"""
        try:
            self._state = ModelState.LOADING
            self._error_message = None
            
            await self.load()
            
            self._current_device = self.target_device
            self._state = ModelState.ACTIVE
            self._last_used = datetime.utcnow()
        except Exception as e:
            self._state = ModelState.ERROR
            self._error_message = str(e)
            raise RuntimeError(f"Failed to load model {self.name}: {e}")
    
    def mark_active(self) -> None:
        """Mark model as recently used"""
        if self._state == ModelState.IDLE:
            self._state = ModelState.ACTIVE
        self._last_used = datetime.utcnow()
    
    def mark_idle(self) -> None:
        """Transition to idle state"""
        if self._state == ModelState.ACTIVE:
            self._state = ModelState.IDLE
    ###############################################################
    async def offload_to_cpu(self) -> None:
        """Move model from GPU to CPU"""
        if self._current_device == "cpu":
            return
        
        if self.offload_to != "cpu":
            raise ValueError(
                f"Model {self.name} not configured for CPU offload "
                f"(offload_to={self.offload_to})"
            )
        
        try:
            await self._offload_cpu()
            self._current_device = "cpu"
            self._state = ModelState.IDLE
        except Exception as e:
            raise RuntimeError(f"Failed to offload {self.name} to CPU: {e}")
    
    async def evict(self) -> None:
        """Completely unload model from memory"""
        try:
            await self.unload()
            if self.model is not None:
                del self.model
            self._state = ModelState.EVICTED
            self._current_device = None
            self.model = None
            
            # Force garbage collection
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception as e:
            raise RuntimeError(f"Failed to evict model {self.name}: {e}")
    #################################################################################
    def get_info(self) -> dict:
        """Get model information"""
        return {
            "name": self.name,
            "type": self.model_type,
            "version": self.version,
            "model_path": self.model_path,
            "state": self._state.value,
            "device": self._current_device,
            "target_device": self.target_device,
            "priority": self.priority,
            "eviction_enabled": self.eviction_enabled,
            "idle_timeout_sec": self.idle_timeout_sec,
            "idle_time_sec": self.idle_time_sec,
            "batching_enabled": self.batching_enabled,
            "max_batch_size": self.max_batch_size,
            "error_message": self._error_message
        }
    
    
    # @abstractmethod
    # async def load(self, device: str) -> None:
    #     """Load model to specified device"""
    #     pass
    
    # @abstractmethod
    # async def unload(self) -> None:
    #     """Unload model and free resources"""
    #     pass
    
    # @abstractmethod
    # async def predict_batch(self, inputs: List[Any]) -> List[Any]:
    #     """Run inference on a batch of inputs"""
    #     pass
    ########################################################
    async def _offload_cpu(self) -> None:
        """Move model to CPU (can be overridden)"""
        if self.model is not None and hasattr(self.model, 'to'):
            await asyncio.to_thread(self.model.to, 'cpu')