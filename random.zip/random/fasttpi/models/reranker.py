
from datetime import datetime
from typing import List, Dict, Any

import torch
from sentence_transformers import CrossEncoder
import asyncio 
import logging
import numpy as np

from models.base import BaseModel
from schemas.model_config import ModelConfig
from core.batcher import Batcher

logger = logging.getLogger(__name__)



# self.device = "cuda" is hardcoded ############ chenge this 
# batch_size=self.inference_batch_size


class RerankerModel(BaseModel):
    """Reranker model implementation using CrossEncoder"""
    def __init__(self, config):
        """
        Initialize reranker from validated config
        
        Args:
            config: Validated ModelConfig with type='reranker'
        """
        super().__init__(config)
        self.max_length = config.max_length
        self.model: CrossEncoder | None = None # Will be set in load_model
        self.batcher: Batcher | None = None
        self.device = "cuda" ####### need to set 
        self._gpu_semaphore = asyncio.Semaphore(1)  ########### need to check 
        logger.info(
            f"Initialized RerankModel '{self.name}' "
            f"(version={self.version}, max_length={self.max_length})"
        )
        
    async def load(self) -> None:          # <-- matches abstract method signature
        """Load CrossEncoder model to the specified device"""
        start_time = datetime.utcnow()

        try:
            logger.info(
                f"Loading reranker '{self.name}' from {self.model_path} to {self.device}"
            )

            def _load_sync():
                return CrossEncoder(
                    self.model_path,
                    max_length=self.max_length,
                    device=self.device
                )

            self.model = await asyncio.to_thread(_load_sync)
            if self.batching_enabled:
                self.batcher = Batcher(
                    max_batch_size=self.max_batch_size,
                    max_wait_ms=self.max_wait_ms,
                    process_fn=self.predict_batch,  # direct reference
                    name=f"{self.name}_batcher",
                )
                self.batcher.start()
                logger.info(f"Started batcher for '{self.name}'")
            load_time = (datetime.utcnow() - start_time).total_seconds()
            logger.info(
                f"Successfully loaded reranker '{self.name}' in {load_time:.2f}s on {self.device}"
            )

        except Exception as e:
            logger.error(f"Failed to load reranker '{self.name}': {e}", exc_info=True)
            raise RuntimeError(f"Failed to load model '{self.name}': {e}")

    async def unload(self) -> None:                     # <-- matches abstract method signature
        """Unload the model and free GPU memory"""
        if self.batcher:
            await self.batcher.stop()
            self.batcher = None
            logger.info(f"Stopped batcher for '{self.name}'")
        if self.model is None:
            logger.debug(f"Model '{self.name}' already unloaded")
            return

        try:
            logger.info(f"Unloading reranker '{self.name}'")
            del self.model
            self.model = None

            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                logger.debug("Cleared CUDA cache")

            logger.info(f"Successfully unloaded reranker '{self.name}'")
        except Exception as e:
            logger.error(f"Error during unload of '{self.name}': {e}", exc_info=True)
            raise RuntimeError(f"Failed to unload model '{self.name}': {e}")        
        
            
    async def predict_batch(
        self, batch_inputs: List[Dict[str, Any]]
        ) -> List[List[Dict[str, Any]]]:

        if self.model is None:
            raise RuntimeError(f"Model '{self.name}' is not loaded")

        pairs: List[tuple[str, str]] = []
        query_boundaries: List[int] = [0]

        for item in batch_inputs:
            query = item["query"]
            chunks = item["chunks"]

            for chunk in chunks:
                pairs.append((query, chunk))

            query_boundaries.append(len(pairs))

        if not pairs:
            return [[] for _ in batch_inputs]

        async with self._gpu_semaphore:
            scores_flat: np.ndarray = await asyncio.to_thread(
                self.model.predict,
                pairs,
                batch_size=16,#self.inference_batch_size,
                show_progress_bar=False,
                convert_to_numpy=True,
                apply_softmax=False,
            )

        results: List[List[Dict[str, Any]]] = []

        for i in range(len(batch_inputs)):
            start = query_boundaries[i]
            end = query_boundaries[i + 1]
            query_scores = scores_flat[start:end]

            sorted_indices = np.argsort(query_scores)[::-1]

            ranked_result = [
                {
                    "index": int(idx),
                    "relevance_score": float(query_scores[idx]),
                }
                for idx in sorted_indices
            ]

            results.append(ranked_result)

        return results

    
    async def submit_request(self, request: Dict[str, Any]) -> Any:
        """Use this in FastAPI endpoint  handles load + batching"""
        await self.ensure_loaded()  # from BaseModel – loads if needed
        self.mark_active()          # update last_used

        if self.batcher is None:
            print("No batcher, running single prediction")
            return (await self.predict_batch([request]))[0]

        return await self.batcher.submit(request)