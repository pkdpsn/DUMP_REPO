import asyncio
import pytest
import pytest_asyncio
import torch

from models.reranker import RerankerModel
from schemas.model_config import ModelConfig


# ---------------------------------------------------------------------
# Device fixture
# ---------------------------------------------------------------------

@pytest.fixture(scope="session")
def device():
    return "cuda" if torch.cuda.is_available() else "cpu"


import yaml
from schemas.model_config import ModelRegistryConfig

def load_model_registry(path: str) -> ModelRegistryConfig:
    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    return ModelRegistryConfig(**raw)


# ---------------------------------------------------------------------
# Async model fixture (STRICT MODE SAFE)
# ---------------------------------------------------------------------

@pytest_asyncio.fixture
async def reranker_model(device):
    CONFIG_PATH = "configs/dev.yaml"
    registry = load_model_registry(CONFIG_PATH)
    
    config = registry.get_model(type="reranker", version="v2")
    model = RerankerModel(config)
    await model.load()

    yield model

    await model.unload()


# ---------------------------------------------------------------------
# 1. Model loads
# ---------------------------------------------------------------------

# @pytest.mark.asyncio
# async def test_model_loads(reranker_model):
#     assert reranker_model.model is not None
#     assert reranker_model.batcher is not None


# # ---------------------------------------------------------------------
# # 2. Single request
# # ---------------------------------------------------------------------

# @pytest.mark.asyncio
# async def test_single_request(reranker_model):
#     request = {
#         "query": "What is machine learning?",
#         "chunks": [
#             "Machine learning is a field of AI.",
#             "I like pizza.",
#             "The sky is blue.",
#         ],
#     }

#     result = await reranker_model.submit_request(request)

#     assert isinstance(result, list)
#     assert len(result) == 3
#     assert "index" in result[0]
#     assert "relevance_score" in result[0]


# # ---------------------------------------------------------------------
# # 3. Concurrent requests (batching)
# # ---------------------------------------------------------------------

# @pytest.mark.asyncio
# async def test_concurrent_requests(reranker_model):
#     requests = [
#         {
#             "query": f"Query {i}",
#             "chunks": ["chunk one", "chunk two", "chunk three"],
#         }
#         for i in range(20)
#     ]

#     tasks = [reranker_model.submit_request(req) for req in requests]
#     results = await asyncio.gather(*tasks)

#     assert len(results) == 20
#     for result in results:
#         assert len(result) == 3


# # ---------------------------------------------------------------------
# # 4. Scores sorted descending
# # ---------------------------------------------------------------------

# @pytest.mark.asyncio
# async def test_scores_sorted_descending(reranker_model):
#     request = {
#         "query": "What is deep learning?",
#         "chunks": [
#             "Deep learning uses neural networks.",
#             "I went to the park yesterday.",
#             "This is about cooking pasta.",
#         ],
#     }

#     result = await reranker_model.submit_request(request)
#     scores = [r["relevance_score"] for r in result]

#     assert scores == sorted(scores, reverse=True)


# ---------------------------------------------------------------------
# 5. Results not mixed across queries
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_results_not_mixed_across_queries(reranker_model):
    req1 = {
        "query": "What is Python?",
        "chunks": ["Python is a programming language.", "I like cats."],
    }

    req2 = {
        "query": "What is cooking?",
        "chunks": ["Cooking involves food.", "Python is a snake."],
    }

    res1, res2 = await asyncio.gather(
        reranker_model.submit_request(req1),
        reranker_model.submit_request(req2),
    )

    assert {r["index"] for r in res1} == {0, 1}
    assert {r["index"] for r in res2} == {0, 1}


# ---------------------------------------------------------------------
# 6. Unload cleans up
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_unload_cleans_up(device):
    CONFIG_PATH = "configs/dev.yaml"
    registry = load_model_registry(CONFIG_PATH)
    
    config = registry.get_model(type="reranker", version="v2")
    model = RerankerModel(config)
    await model.load()
    await model.unload()

    assert model.model is None
    assert model.batcher is None
