import asyncio
import time
import pytest
import pytest_asyncio
import torch

from models.reranker import RerankerModel
from core.batcher import Batcher

import yaml
from schemas.model_config import ModelRegistryConfig

def load_model_registry(path: str) -> ModelRegistryConfig:
    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    return ModelRegistryConfig(**raw)
# ---------------------------------------------------------------------
# Register slow marker (pytest.ini is better, but this avoids warnings)
# ---------------------------------------------------------------------

pytestmark = pytest.mark.slow


class SpyRerankerModel(RerankerModel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.batch_sizes = []
        self.batch_timestamps = []

    async def predict_batch(self, batch_inputs):
        # This is called by the batcher — guaranteed
        self.batch_sizes.append(len(batch_inputs))
        self.batch_timestamps.append(time.time())
        return await super().predict_batch(batch_inputs)


@pytest.mark.asyncio
async def test_burst_and_delayed_batching_behavior():
    """
    1. Fire 100 requests instantly
    2. Wait ~30s
    3. Fire 35 more requests
    4. Verify batching behavior
    """

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # ---------------------------------------------------------
    # Load config
    # ---------------------------------------------------------

    registry = load_model_registry("configs/dev.yaml")
    config = registry.get_model(type="reranker", version="v2")
    config.device = device

    # ---------------------------------------------------------
    # Use spy model
    # ---------------------------------------------------------

    model = SpyRerankerModel(config)
    await model.load()

    # ---------------------------------------------------------
    # Phase 1: 100 instant requests
    # ---------------------------------------------------------

    burst_requests = [
        {
            "query": f"Query {i}",
            "chunks": ["chunk one", "chunk two", "chunk three"],
        }
        for i in range(100)
    ]

    await asyncio.gather(
        *[model.submit_request(req) for req in burst_requests]
    )

    # ---------------------------------------------------------
    # Idle gap
    # ---------------------------------------------------------

    await asyncio.sleep(30)

    # ---------------------------------------------------------
    # Phase 2: delayed requests
    # ---------------------------------------------------------

    delayed_requests = [
        {
            "query": f"Late query {i}",
            "chunks": ["chunk A", "chunk B"],
        }
        for i in range(35)
    ]

    await asyncio.gather(
        *[model.submit_request(req) for req in delayed_requests]
    )

    await model.unload()

    # ---------------------------------------------------------
    # Assertions
    # ---------------------------------------------------------

    batch_sizes = model.batch_sizes
    batch_times = model.batch_timestamps

    print("Observed batch sizes:", batch_sizes)
    print("*"*100)
    assert len(batch_sizes) > 1, "No batching observed"

    # With max_batch_size=16:
    # 100 → ~6–7 batches
    # 35  → ~2–3 batches
    assert len(batch_sizes) < 20, "Too many batches — batching ineffective"

    assert max(batch_sizes) >= 8, "Batches too small — batching not effective"

    assert max(batch_times) - min(batch_times) > 20, "Batches did not span both phases"
