import asyncio
import httpx
import time

URL = "http://localhost:8000/infer"

async def send_request(client, i):
    payload = {"text": f"request-{i}"}
    r = await client.post(URL, json=payload)
    return r.json()

async def main():
    start = time.time()
    i =1
    while i< 128:
        i*=2
        async with httpx.AsyncClient(timeout=10.0) as client:
            tasks = [send_request(client, i) for i in range(i)]
            results = await asyncio.gather(*tasks)

        for r in results:
            print(r)
            
    

    print(f"\nTotal time: {time.time() - start:.3f}s")

if __name__ == "__main__":
    asyncio.run(main())