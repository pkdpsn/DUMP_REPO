---
title: Introduction
description: A drop-in replacement for react-markdown, designed for AI-powered streaming.
type: overview
summary: Streamdown renders Markdown in real-time as tokens arrive from AI models, with built-in support for syntax highlighting, math, diagrams, and more.
related:
  - /docs/getting-started
---

# Introduction



Streamdown is a React component library that makes rendering streaming Markdown content seamless and beautiful. Built specifically for AI-powered applications, it handles the unique challenges that arise when Markdown is tokenized and streamed in real-time.

## The Problem with Streaming Markdown

When you stream Markdown content from AI models, new challenges emerge that traditional Markdown renderers weren't designed to handle:

* **Incomplete syntax** - Bold text that hasn't been closed yet: `**This is bol`
* **Partial code blocks** - Code blocks missing their closing backticks
* **Unterminated links** - Links without closing brackets: `[Click here`
* **Progressive rendering** - Content that updates token-by-token

Traditional Markdown renderers like `react-markdown` will either render these incomplete elements incorrectly or not at all, creating a jarring user experience.

## The Streamdown Solution

Streamdown intelligently handles incomplete Markdown by:

1. **Parsing incomplete blocks** - Automatically detects and completes unterminated Markdown syntax
2. **Progressive formatting** - Applies styling to partial content as it streams in
3. **Seamless transitions** - Smoothly updates from incomplete to complete states
4. **Zero configuration** - Works out of the box with sensible defaults
